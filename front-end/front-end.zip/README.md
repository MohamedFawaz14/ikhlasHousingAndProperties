
  # Responsive Real Estate Website

  This is a code bundle for Responsive Real Estate Website. The original project is available at https://www.figma.com/design/NY1zBf2hZ3C1CxAVDWb8TB/Responsive-Real-Estate-Website.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  